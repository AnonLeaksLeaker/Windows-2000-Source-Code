//--------------------------------------------------------------------
//
//  Microsoft Windows
//
//  Copyright (C) Microsoft Corporation, 1995 - 1999
//
//  File:       resource.h
//
//  Contents:   the resource header for setreg.cpp 
//
//
//  History:    05-May-97   xiaohs   created
//              
//--------------------------------------------------------------------------
//defintion for string IDS
#define	IDS_TRUE							6002
#define	IDS_FALSE							6003
#define	IDS_KEY_STATE						6004
#define	IDS_NAME_TEST_ROOT					6111
#define	IDS_NAME_EXPIRATION					6112
#define	IDS_NAME_REVOCATION					6113
#define	IDS_NAME_OFFLINE_INDIVIDUAL			6114
#define	IDS_NAME_OFFLINE_COMMERCIAL			6115
#define	IDS_NAME_JAVA_INDIVIDUAL			6116
#define	IDS_NAME_JAVA_COMMERCIAL			6117
#define	IDS_NAME_VERSION_ONE				6118
#define IDS_NAME_REVOCATIONONTS             6119
#define	IDS_NAME_ALLOWONLYPERTRUST			6120
