#include <nt.h>
#include <windef.h>
