#ifndef _VC_VER_INC
#include "..\include\vcver.h"
#endif

#define DBG_API_VERSION	7
#define DBG_API_SUBVERSION 0
