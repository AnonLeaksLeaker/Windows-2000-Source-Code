#pragma once
#if !defined(_miscimage_h)
#define _miscimage_h 1

#define IMAGE_FILE_MACHINE_IA64     1996

#endif
