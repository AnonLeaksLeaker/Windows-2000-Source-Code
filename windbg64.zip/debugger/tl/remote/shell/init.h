
int
CPCopyString(LPSTR * lplps, LPSTR lpT, char chEscape, BOOL fQuote);

LPSTR
GetArg(LPSTR *lpp);

