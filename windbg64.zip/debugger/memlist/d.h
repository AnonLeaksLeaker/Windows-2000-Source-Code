


typedef LPVOID LPV;

