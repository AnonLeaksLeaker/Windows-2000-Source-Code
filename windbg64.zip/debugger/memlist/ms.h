#define CVMessage(a,b,cCC)
#define ERRORMSG 0
#define ENOMEM 1
#define MSGBOX 2
#define SHFLAG BOOL

#define HVOID LPV
