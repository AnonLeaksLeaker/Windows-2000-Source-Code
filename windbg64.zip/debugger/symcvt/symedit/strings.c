#define LANG_USE        LANGUAGE LANG_ENGLISH, SUBLANG_ENGLISH_US
#include        "strings.h"
