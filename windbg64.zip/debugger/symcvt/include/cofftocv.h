/*
 *      cofftocv.h -- This file contains prototypes, type definitions
 *      and other information relative to COFF to CODEVIEW converstions
 */

#ifdef __cplusplus
extern "C" {
#endif

BOOL    ConvertCoffToCv( PPOINTERS p );

#ifdef __cplusplus
} // extern "C" {
#endif
