/*
 *      symtocv.h -- This file contains prototypes, type definitions
 *      and other information relative to SYM FILES to CODEVIEW converstions
 */

#ifdef __cplusplus
extern "C" {
#endif

BOOL    ConvertSymToCv( PPOINTERS p );

#ifdef __cplusplus
} // extern "C" {
#endif
