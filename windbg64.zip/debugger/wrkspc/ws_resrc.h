//#define ERR_Registry_Write_Permission 32000

