#include "precomp.hxx"
#pragma hdrstop



//
// WinDbgRM
//
CWindbgrm_RM_WKSP           g_RM_Windbgrm_WkSp;
CAll_TLs_RM_WKSP            &g_RM_All_Tls_WkSp = g_RM_Windbgrm_WkSp.m_dynacont_All_TLs;


//
// WinDbg
//
// Defined in windbg
