
DWORD FTrojanCreateSQLThread( HTHDX pthd, UOFFSET pDebugBreak, HANDLE *pHandle );

