#if ! defined( _RES_STR_ )
#define _RES_STR_

#define DECL_XOSD(n, v, s) v, s
STRINGTABLE
BEGIN

#include <xosd.h>

END

#endif // _RES_STR_
