/*++

Copyright (c) 1995  Microsoft Corporation

Module Name:

    emdp_plt.h

Abstract:

    Target platform independent

Author:

    RafaelL 18-Sep-1995

Environment:

    Win32, User Mode

--*/

#pragma warning( disable: 4200)

#include "biavst.h"
#include "emdp.h"

