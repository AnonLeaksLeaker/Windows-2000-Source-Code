/*++ BUILD Version: 0001    // Increment this if a change has global effects
---*/

HWND GetLocalHWND(void);
LRESULT CALLBACK LocalEditProc(HWND hwnd,UINT msg, WPARAM wParam, LPARAM lParam);
