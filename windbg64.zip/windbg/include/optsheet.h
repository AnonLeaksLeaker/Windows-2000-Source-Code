#ifndef __OPTIONS_PROP_SHEET_H__
#define __OPTIONS_PROP_SHEET_H__

INT_PTR 
DisplayOptionsPropSheet(
                        HWND hwndOwner, 
                        HINSTANCE hinst,
                        int nStartPage
                        );

#endif

