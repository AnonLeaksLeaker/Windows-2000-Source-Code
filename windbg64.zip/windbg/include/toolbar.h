/*++ BUILD Version: 0003    // Increment this if a change has global effects
---*/


HWND GetHwnd_Toolbar();
LPSTR GetToolTipTextFor_Toolbar(UINT uToolbarId);
void WindbgCreate_Toolbar(HWND hwndParent);

//Update toolbar
void Show_Toolbar(BOOL bShow);

void EnableToolbarControls();
