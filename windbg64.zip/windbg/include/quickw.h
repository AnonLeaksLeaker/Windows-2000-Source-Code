/*++ BUILD Version: 0001    // Increment this if a change has global effects
---*/


// Watch Tree access routines:

LRESULT CALLBACK QuickEditProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);


