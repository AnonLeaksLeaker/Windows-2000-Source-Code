#include <windows.h>

#include <ntsdsup.h>
#include "ntsdtok.h"

#define NTEXPR_EXCEPTION    0x60db0001


