/*++ BUILD Version: 0001    // Increment this if a change has global effects
---*/
#define ID_CHANGE_ALL         108
#define ID_CHANGE_CANCEL      111
#define ID_CHANGE_HELP        112
#define ID_CHANGE_MATCHUPLO   105
#define ID_CHANGE_OK          109
#define ID_CHANGE_REGEXP      107
#define ID_CHANGE_WHAT        102
#define ID_CHANGE_TO            101
#define ID_CHANGE_CONFIRM     103
#define ID_CHANGE_WHOLEWORD   104
