/*++ BUILD Version: 0001    // Increment this if a change has global effects
---*/
#define ID_SYNTAX_C        105
#define ID_SYNTAX_CANCEL   109
#define ID_SYNTAX_HELP     110
#define ID_SYNTAX_NONE     102
#define ID_SYNTAX_OK       107
#define ID_SYNTAX_PASCAL   106
