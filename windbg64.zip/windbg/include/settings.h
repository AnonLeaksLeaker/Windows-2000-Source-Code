/*++ BUILD Version: 0001    // Increment this if a change has global effects
---*/
#define ID_SETTINGS_AUTO           105
#define ID_SETTINGS_BUTTONCURSOR   123
#define ID_SETTINGS_BUTTONHELP     122
#define ID_SETTINGS_C              102
#define ID_SETTINGS_CANCEL         121
#define ID_SETTINGS_HELP           113
#define ID_SETTINGS_KEEPTABS       109
#define ID_SETTINGS_OK             120
#define ID_SETTINGS_PASCAL         104
#define ID_SETTINGS_PROMPT         118
#define ID_SETTINGS_SAVEBEFORE     117
#define ID_SETTINGS_SCROLLBARS     110
#define ID_SETTINGS_SMARTHELP      115
#define ID_SETTINGS_TABSTOPS       107
