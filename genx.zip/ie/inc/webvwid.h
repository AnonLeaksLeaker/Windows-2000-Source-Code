// Events IDs for Thumb Control
#define DISPID_ONTHUMBNAILREADY         200

// Property IDs for WebView Folder Icon
#define DISPID_PROP_WVFOLDERICON_SCALE              1
#define DISPID_PROP_WVFOLDERICON_PATH               2
#define DISPID_PROP_WVFOLDERICON_VIEW               3
#define DISPID_PROP_WVFOLDERICON_ADVPROPERTY        4
