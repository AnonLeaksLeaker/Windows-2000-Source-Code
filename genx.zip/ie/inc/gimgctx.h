//+-------------------------------------------------------------------------
//
//  Microsoft Windows
//  Copyright 1996-1998 Microsoft Corporation. All Rights Reserved.
//
//  File: gimgctx.h
//
//--------------------------------------------------------------------------

#ifndef _GImgCtx_H_
#define _GImgCtx_H_

// include core IImgCtx header
#include <iimgctx.h>

// {46482189-b251-11d2-a438-00c04fb177e3}
DEFINE_GUID(CLSID_Glass_IImgCtx, 0x46482189,0xb251,0x11d2,0xa4,0x38,0x00,0xc0,0x4f,0xb1,0x77,0xe3);

#endif
