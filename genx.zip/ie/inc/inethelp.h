//*********************************************************************
//*                  Microsoft Windows                               **
//*            Copyright(c) Microsoft Corp., 1996-1998               **
//*********************************************************************

//
// HELP.H - IDHs for the Internet Control Panel
//

//
// GLOBALS... ie... used to give the same info on every page
//

#include <iehelpid.h>
