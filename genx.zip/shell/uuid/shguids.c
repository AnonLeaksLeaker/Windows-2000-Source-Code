#define INITGUID
#include <guiddef.h>

#include <shlguid.h>
#include <commdlg.h>
#include <dsclient.h>
#include <dsclintp.h>
#include <cmnquery.h>
#include <cmnquryp.h>
#include <dsquery.h>
#include <dsqueryp.h>
