#define MAP_DEBUG_TEST
#include "mapdebug.c"
