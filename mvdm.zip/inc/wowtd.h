// This is here so it can be h2inc'd for fastwow.asm
//


// Note:  The offset definitons below HAVE TO match the offsets in wow32.h
//   From the TD struct:
#define cbOffCOMMDLGTD 3*sizeof(DWORD)


// Note:  The offset definitons below HAVE TO match the offsets in wow.h
//   From the VDMFRAME struct:
#define cbOffwThunkCSIP 0x1c


