/*++ BUILD Version: 0001
 *
 *  MVDM v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WOWEXP.H
 *  WOW32 exports
 *
 *  History:
 *  10-May-1991 Jeff Parsons (jeffpar)
 *  Created.
--*/

extern VOID FAR PASCAL W32Dispatch(VOID);
