/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WITBL.H
 *  WOW32 16-bit Internal API tables
 *
 *  History:
 *  Created 22-Apr-1992 by FritzS
--*/



/* Internal dispatch table
 */
extern W32 aw32Internal[];


#ifdef DEBUG_OR_WOWPROFILE
extern INT iInternalMax;
#endif
