/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WSTBL.H
 *  WOW32 16-bit Sound API tables
 *
 *  History:
 *  Created 27-Jan-1991 by Jeff Parsons (jeffpar)
--*/



/* Sound dispatch table
 */
extern W32 aw32Sound[];


#ifdef DEBUG_OR_WOWPROFILE
extern INT iSoundMax;
#endif
