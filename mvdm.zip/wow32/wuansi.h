/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WUANSI.H
 *  WOW32 16-bit User API support
 *
 *  History:
 *  Created 07-Mar-1991 by Jeff Parsons (jeffpar)
--*/

/*

ULONG FASTCALL WU32AnsiLower(PVDMFRAME pFrame);
ULONG FASTCALL WU32AnsiLowerBuff(PVDMFRAME pFrame);
ULONG FASTCALL WU32AnsiNext(PVDMFRAME pFrame);
ULONG FASTCALL WU32AnsiPrev(PVDMFRAME pFrame);
ULONG FASTCALL WU32AnsiUpper(PVDMFRAME pFrame);
ULONG FASTCALL WU32AnsiUpperBuff(PVDMFRAME pFrame);

*/
