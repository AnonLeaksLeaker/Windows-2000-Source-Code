/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WMMTBL.H
 *  WOW32 16-bit MultiMedia API tables
 *
 *  History:
 *  Created 21-Jan-1992 by Mike Tricker (miketri), after jeffpar
--*/



/* MMEDIA dispatch table
 */
extern W32 aw32MMED[];


#ifdef DEBUG_OR_WOWPROFILE
extern INT iMMEDMax;
#endif
