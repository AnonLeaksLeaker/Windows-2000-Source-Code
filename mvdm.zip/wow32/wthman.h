/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WTHMAN.H
 *  WOW32 16-bit ToolHelp API support (manually-coded thunks for
 *  unimplemented 16-bit APIs).
 *
 *  History:
 *  12-Nov-92 davehart Created using wkman.h as template
 *
--*/

