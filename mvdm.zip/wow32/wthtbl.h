/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WKTBL.H
 *  WOW32 16-bit Kernel API tables
 *
 *  History:
 *  Created 12-Nov-1992 by Dave Hart (davehart) using wktbl.h as template
 *
--*/



/* ToolHelp dispatch table
 */
extern W32 aw32ToolHelp[];


#ifdef DEBUG_OR_WOWPROFILE
extern INT iToolHelpMax;
#endif
