/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WSMAN.H
 *  WOW32 16-bit Sound API support (manually-coded thunks)
 *
 *  History:
 *  Created 27-Jan-1991 by Jeff Parsons (jeffpar)
--*/



/* Sound thunks
 */


ULONG FASTCALL WS32DoBeep(PVDMFRAME pFrame);
