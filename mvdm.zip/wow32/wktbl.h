/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WKTBL.H
 *  WOW32 16-bit Kernel API tables
 *
 *  History:
 *  Created 27-Jan-1991 by Jeff Parsons (jeffpar)
--*/



/* Kernel dispatch table
 */
extern W32 aw32Kernel[];


#ifdef DEBUG_OR_WOWPROFILE
extern INT iKernelMax;
#endif
