/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WKBTBL.H
 *  WOW32 16-bit Keyboard API tables
 *
 *  History:
 *  Created 27-Jan-1991 by Jeff Parsons (jeffpar)
--*/



/* Keyboard dispatch table
 */
extern W32 aw32Keyboard[];


#ifdef DEBUG_OR_WOWPROFILE
extern INT iKeyboardMax;
#endif
