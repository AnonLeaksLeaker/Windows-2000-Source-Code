/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WUTBL.H
 *  WOW32 16-bit User API tables
 *
 *  History:
 *  Created 27-Jan-1991 by Jeff Parsons (jeffpar)
--*/



/* User dispatch table
 */
extern W32 aw32User[];



#ifdef DEBUG_OR_WOWPROFILE
extern INT iUserMax;
#endif
