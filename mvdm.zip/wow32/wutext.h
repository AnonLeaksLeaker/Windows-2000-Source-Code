/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WUTEXT.H
 *  WOW32 16-bit User API support
 *
 *  History:
 *  Created 07-Mar-1991 by Jeff Parsons (jeffpar)
--*/



ULONG FASTCALL WU32GetTabbedTextExtent(PVDMFRAME pFrame);
ULONG FASTCALL WU32TabbedTextOut(PVDMFRAME pFrame);
