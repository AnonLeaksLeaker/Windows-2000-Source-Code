/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WGTEXT.H
 *  WOW32 16-bit GDI API support
 *
 *  History:
 *  Created 07-Mar-1991 by Jeff Parsons (jeffpar)
--*/



ULONG FASTCALL WG32ExtTextOut(PVDMFRAME pFrame);
ULONG FASTCALL WG32GetTextExtent(PVDMFRAME pFrame);
ULONG FASTCALL WG32GetTextMetrics(PVDMFRAME pFrame);
