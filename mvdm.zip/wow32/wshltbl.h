/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, Microsoft Corporation
 *
 *  WSHLTBL.H
 *  WOW32 16-bit SHELL API tables
 *
 *  History:
 *  Created 14-April-1992 by Chandan Chauhan (ChandanC)
 *
--*/



/* SHELL dispatch table
 */
extern W32 aw32Shell[];



#ifdef DEBUG_OR_WOWPROFILE
extern INT iShellMax;
#endif
