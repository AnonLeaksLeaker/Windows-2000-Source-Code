/*++ BUILD Version: 0001
 *
 *  WOW v1.0
 *
 *  Copyright (c) 1991, 1992, 1993 Microsoft Corporation
 *
 *  WOWTABLE.H
 *  WOW32 API thunk table
 *
--*/



/* thunk table
 */
extern W32 aw32WOW[];


#ifdef DEBUG_OR_WOWPROFILE
extern INT cAPIThunks;
#endif
