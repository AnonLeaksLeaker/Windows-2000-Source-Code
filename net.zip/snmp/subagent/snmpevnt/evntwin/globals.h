#ifndef _globals_h

class CTrapReg;
extern CTrapReg g_reg;
extern TCHAR g_chThousandSep;  // The thousands separator character
extern BOOL g_abLcSourceSortAscending[];
extern BOOL g_abLcEventsSortAscending[];

#define MAX_STRING 1024
#define FILE_DEF_EXT    _T("*.*")

#endif //_globals_h
