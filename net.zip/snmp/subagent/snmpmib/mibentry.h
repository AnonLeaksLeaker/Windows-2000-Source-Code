/*++

Copyright (c) 1998  Microsoft Corporation

Module Name:

Abstract:

Revision History:

--*/

#include "snmpmgmt.h"

#ifndef _MIBENTRY_H_
#define _MIBENTRY_H_

extern SnmpMibView view_snmp;

#endif // _MIBENTRY_H_
