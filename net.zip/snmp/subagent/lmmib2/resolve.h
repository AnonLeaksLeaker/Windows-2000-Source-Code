/*++

Copyright (c) 1992-1996  Microsoft Corporation

Module Name:

    resolve.h

Abstract:

    All constants, types, and prototypes to resolve Variable Bindings.

Environment:

    User Mode - Win32

Revision History:

    10-May-1996 DonRyan
        Removed banner from Technology Dynamics, Inc.

--*/
 
#ifndef resolve_h
#define resolve_h

//--------------------------- PUBLIC CONSTANTS ------------------------------

//--------------------------- PUBLIC STRUCTS --------------------------------

//--------------------------- PUBLIC VARIABLES --(same as in module.c file)--

//--------------------------- PUBLIC PROTOTYPES -----------------------------

//------------------------------- END ---------------------------------------

#endif /* resolve_h */

