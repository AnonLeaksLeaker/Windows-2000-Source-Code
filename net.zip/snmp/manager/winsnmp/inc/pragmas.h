#ifndef _PRAGMAS_H_
#define _PRAGMAS_H_
#pragma warning (disable : 4001) // single  line comments
//
// pragma.h
//
// Utility include for NetPlus WinSNMP
// Copyright 1995-1997 ACE*COMM Corp
// Rleased to Microsoft under Contract
// Beta 1 version, 970228
// Bob Natale (bnatale@acecomm.com)
//
#define __export
#define WAKRELVER "Release 3.MS"
#define WAKRELDATE "19970221" 
#endif   
