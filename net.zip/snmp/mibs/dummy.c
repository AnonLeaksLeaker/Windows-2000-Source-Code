
/**
    This is just a dummy C file for the compiler to have
**/

void dummy_main(void)
{
    return;
}
