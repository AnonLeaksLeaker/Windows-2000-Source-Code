#ifndef _PRECOMP_H_
#define _PRECOMP_H_

#include <windows.h>
#include <winsock2.h>
#include <ws2spi.h>
#include <rpc.h>

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tchar.h>


#endif  // _PRECOMP_H_

